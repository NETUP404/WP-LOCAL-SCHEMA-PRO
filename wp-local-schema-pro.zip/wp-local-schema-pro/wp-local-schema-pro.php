<?php
/*
Plugin Name: WP Local Schema PRO
Description: Todo el Schema Local SEO, tienda, directorios, ratings, reviews y utilidades SEO local PRO.
Version: 2.0.0
Author: NETUP404 + Copilot
Text Domain: wp-local-schema-pro
Domain Path: /languages
License: GPLv2 or later
*/

if (!defined('ABSPATH')) exit;

define('WP_LSP_PATH', plugin_dir_path(__FILE__));
define('WP_LSP_URL', plugin_dir_url(__FILE__));

add_action('plugins_loaded', function() {
    load_plugin_textdomain('wp-local-schema-pro', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

require_once WP_LSP_PATH . 'includes/field-definitions.php';
require_once WP_LSP_PATH . 'includes/helpers.php';
require_once WP_LSP_PATH . 'includes/output-schema.php';

// SOLO carga el panel cuando es necesario
function wp_lsp_render_admin_panel() {
    require WP_LSP_PATH . 'includes/admin-panel.php';
}

add_action('admin_menu', function() {
    add_menu_page(
        'WP Local Schema PRO',
        'WP Local Schema PRO',
        'manage_options',
        'wp-local-schema-pro',
        'wp_lsp_render_admin_panel',
        'dashicons-location-alt'
    );
});

register_activation_hook(__FILE__, function() {
    if (!get_option('wp_local_schema_pro_options')) {
        add_option('wp_local_schema_pro_options', []);
    }
});