document.addEventListener('DOMContentLoaded', function() {
    const typeSelector = document.getElementById('schema_type');
    const allFieldGroups = document.querySelectorAll('.field-group');

    function updateFields() {
        const selectedType = typeSelector.value;
        allFieldGroups.forEach(group => {
            if (group.classList.contains('group-' + selectedType)) {
                group.style.display = 'block';
            } else {
                group.style.display = 'none';
            }
        });
    }

    typeSelector.addEventListener('change', updateFields);
    updateFields(); // On load
});