<?php
/*
Plugin Name: WP Local Schema PRO
Description: ...
Version: 2.0.0
Author: NETUP404 + Copilot
Text Domain: wp-local-schema-pro
Domain Path: /languages
License: GPLv2 or later
*/

// No espacios ni líneas fuera de PHP

if (!defined('ABSPATH')) exit;

define('WP_LSP_PATH', plugin_dir_path(__FILE__));
define('WP_LSP_URL', plugin_dir_url(__FILE__));

add_action('plugins_loaded', function() {
    load_plugin_textdomain('wp-local-schema-pro', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

require_once WP_LSP_PATH . 'includes/field-definitions.php';
require_once WP_LSP_PATH . 'includes/helpers.php';
require_once WP_LSP_PATH . 'includes/admin-panel.php';
require_once WP_LSP_PATH . 'includes/output-schema.php';

register_activation_hook(__FILE__, 'wp_lsp_activate');
function wp_lsp_activate() {
    if (!get_option('wp_local_schema_pro_options')) {
        add_option('wp_local_schema_pro_options', []);
    }
}