<?php
/*
Plugin Name: WP Local Schema PRO
Description: Plugin profesional para gestionar schema local de tu negocio en WordPress.
Version: 1.0.0
Author: Tu Nombre
*/

if (!defined('ABSPATH')) exit;

define('WP_LSP_PATH', plugin_dir_path(__FILE__));

function wp_lsp_admin_assets() {
    wp_enqueue_style('wp-lsp-admin-style', plugin_dir_url(__FILE__) . 'assets/style.css', [], '1.0.0');
}
add_action('admin_enqueue_scripts', 'wp_lsp_admin_assets');

function wp_lsp_add_admin_menu() {
    add_menu_page(
        'WP Local Schema PRO',
        'Local Schema PRO',
        'manage_options',
        'wp-local-schema-pro',
        'wp_lsp_render_admin_panel',
        'dashicons-location-alt'
    );
}
add_action('admin_menu', 'wp_lsp_add_admin_menu');

function wp_lsp_render_admin_panel() {
    require WP_LSP_PATH . 'includes/admin-panel.php';
}