<?php
// Archivo de prueba limpio