<?php
if (!defined('ABSPATH')) exit;
?>
<div class="wrap">
  <h1>WP Local Schema PRO</h1>
  <form method="post" class="wp-lsp-form">
    <?php
      // Aquí van tus campos. Puedes incluirlos o escribirlos directamente:
      // include __DIR__ . '/fields-general.php';
      // include __DIR__ . '/fields-organizacion.php';
      // include __DIR__ . '/fields-persona.php';
      // Ejemplo de campo:
    ?>
    <table class="form-table">
      <tr>
        <th scope="row"><label for="wp_lsp_nombre">Nombre del negocio</label></th>
        <td><input name="wp_lsp_nombre" type="text" id="wp_lsp_nombre" value="" class="regular-text"></td>
      </tr>
      <tr>
        <th scope="row"><label for="wp_lsp_direccion">Dirección</label></th>
        <td><input name="wp_lsp_direccion" type="text" id="wp_lsp_direccion" value="" class="regular-text"></td>
      </tr>
      <!-- Añade más campos aquí -->
    </table>
    <div class="wp-lsp-buttons">
      <button type="submit" class="button button-primary">Guardar cambios</button>
      <button type="reset" class="button">Restablecer</button>
      <a href="https://tudocumentacion.com" target="_blank" class="button button-secondary">Ayuda</a>
    </div>
  </form>
</div>